using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VoxPalette : MonoBehaviour
{
    public VoxelBlock[] Blocktypes = new VoxelBlock[256];
}
