using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChunkMap : MonoBehaviour
{
    public Chunk[,] ChunkMapData = new Chunk[8,8];
}
