using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum SoundProfile
{
    Wood,
    Brick,
    Concrete,
    Stone,
    Metal,
    Glass,
    Carpet,
    Grass,
    Dirt,
    Sand,
    Marble,
    Tile,
    Cardboard,
    Water,
    Oil,
    Leaves,
    Rubber,
    Plastic
}
