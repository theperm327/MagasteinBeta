using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SectorAdress : MonoBehaviour
{
    public int x;
    public int z;    
}
