using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChunkAddress : MonoBehaviour
{
    public int x;
    public int y;
    public int z;
}
