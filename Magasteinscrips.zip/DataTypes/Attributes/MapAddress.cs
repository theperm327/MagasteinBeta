using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapAddress : MonoBehaviour
{
    public int x;
    public int z;
}
