using System.Collections;
using System.Collections.Generic;
using UnityEngine;

    public enum FaceDirection
    {
        North,
        South,
        East,
        West,
        Up,
        Down
    }
