using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MagBlock : MonoBehaviour
{
    public MagBlockAdress MagBlockAddy;
    public int[,,] MagaBlockData = new int[3, 3, 3];
}
