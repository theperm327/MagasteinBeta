using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Protagonist : MonoBehaviour
{
    public int ProtagonistAmmo;
    public int ProtagonistHealth;
    public bool[] ProtagonistGuns;
    public int GunNumber;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
